# webclient.py
#
# 파이썬을 이용한 web client 프로그램
#
import urllib.request   # HTTP를 이용한 요청용 패키지 Load 

# 지정된 Web Server에 요청하여 결과를 print()로 출력
print( urllib.request.urlopen( "http://www.example.com" ).read().decode( 'utf-8' ) )
